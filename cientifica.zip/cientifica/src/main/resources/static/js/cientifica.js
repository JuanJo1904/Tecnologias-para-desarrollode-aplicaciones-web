function setDigito(digito) {
    let display = document.getElementById('display');

    if (display.value === "0") {
        display.value = digito;
    } else {
        display.value += digito;
    }
}

function setOperador(operador) {
    let display = document.getElementById('display');
    display.value += operador;
}

function borrar() {
    let display = document.getElementById('display');
    display.value = '0';
}

function obtenerResultado() {
    let display = document.getElementById('display');

    try {

        // Validación de 0/0
        if (display.value.includes("0/0")) {
            alert("Error: No se puede dividir 0/0");
            display.value = "0";
            return;
        }

        let resultado = eval(display.value);

        // Validación de infinito
        if (resultado === Infinity || resultado === -Infinity) {
            alert("Error: División entre cero");
            display.value = "0";
            return;
        }

        // Validación NaN
        if (isNaN(resultado)) {
            alert("Operación inválida");
            display.value = "0";
            return;
        }

        display.value = resultado;

    } catch (error) {
        alert("Error en la operación");
        display.value = "0";
    }
}

function raizCuadrada() {
    let display = document.getElementById('display');

    let valor = parseFloat(display.value);

    if (valor < 0) {
        alert("No existe raíz cuadrada de números negativos");
        return;
    }

    display.value = Math.sqrt(valor);
}

function logaritmo() {
    let display = document.getElementById('display');

    let valor = parseFloat(display.value);

    if (valor <= 0) {
        alert("El logaritmo solo acepta números positivos");
        return;
    }

    display.value = Math.log10(valor);
}

function potencia() {
    let display = document.getElementById('display');
    display.value += '**';
}